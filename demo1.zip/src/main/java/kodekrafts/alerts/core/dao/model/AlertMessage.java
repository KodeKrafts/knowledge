package kodekrafts.alerts.core.dao.model;

import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity(name = "alert_message")

public class AlertMessage {
    @Id
    @Column(name="id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name="correlation_id")
    private String correlationId;
    @Column(name="customer_id")
    private String customerId;

    @Column(name="bank_number")
    private String bankNumber;
    @Column(name="source_channel")
    private String sourceChannel;

    @Column(name="notification_type")
    private String notificationType;
    @Column(name="created")
    private LocalDateTime created;
    @Column(name="updated")
    private LocalDateTime updated;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "push_id", referencedColumnName = "id")
    private PushMessage push;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "sms_id", referencedColumnName = "id")
    private PushMessage sms;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "email_id", referencedColumnName = "id")
    private PushMessage email;
}

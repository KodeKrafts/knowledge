package kodekrafts.alerts.core.dao.model;

//import com.kodekrafts.notification.model.Phone;
import jakarta.persistence.*;

import java.time.LocalDateTime;
import java.util.List;

@Entity(name = "notification")
public class Notification {

    @Id
    @Column(name="notification_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long notificationId;
    @Column(name="correlation_id")
    private String correlationId;
    @Column(name="customer_id")
    private String customerId;
    @Column(name="extended_msg")
    private String extendedMsg;
    @Column(name="language")
    private String language;
    @Column(name="customer_event_name")
    private String customerEventName;
    @Column(name="fininst_key")
    private String fininstKey;
    @Column(name="application_name")
    private String applicationName;
    @Column(name="customer_event_id")
    private String customerEventId;

    public long getNotificationId() {
        return notificationId;
    }

    public void setNotificationId(long notificationId) {
        this.notificationId = notificationId;
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getExtendedMsg() {
        return extendedMsg;
    }

    public void setExtendedMsg(String extendedMsg) {
        this.extendedMsg = extendedMsg;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getCustomerEventName() {
        return customerEventName;
    }

    public void setCustomerEventName(String customerEventName) {
        this.customerEventName = customerEventName;
    }

    public String getFininstKey() {
        return fininstKey;
    }

    public void setFininstKey(String fininstKey) {
        this.fininstKey = fininstKey;
    }

    public String getApplicationName() {
        return applicationName;
    }

    public void setApplicationName(String applicationName) {
        this.applicationName = applicationName;
    }

    public String getCustomerEventId() {
        return customerEventId;
    }

    public void setCustomerEventId(String customerEventId) {
        this.customerEventId = customerEventId;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getPhoneType() {
        return phoneType;
    }

    public void setPhoneType(String phoneType) {
        this.phoneType = phoneType;
    }

    public Boolean getPushNotification() {
        return isPushNotification;
    }

    public void setPushNotification(Boolean pushNotification) {
        isPushNotification = pushNotification;
    }

    public Boolean getSMS() {
        return isSMS;
    }

    public void setSMS(Boolean SMS) {
        isSMS = SMS;
    }

    public Boolean getEmail() {
        return isEmail;
    }

    public void setEmail(Boolean email) {
        isEmail = email;
    }

    public String getSrcChannel() {
        return srcChannel;
    }

    public void setSrcChannel(String srcChannel) {
        this.srcChannel = srcChannel;
    }

    public LocalDateTime getCreated() {
        return created;
    }

    public void setCreated(LocalDateTime created) {
        this.created = created;
    }

    public LocalDateTime getUpdated() {
        return updated;
    }

    public void setUpdated(LocalDateTime updated) {
        this.updated = updated;
    }

    @Column(name="email_id")
    private String emailId;
    @Column(name="phone_number")
    private String phoneNumber;
    @Column(name="phone_type")
    private String phoneType;
    @Column(name="is_push_notification")
    private Boolean isPushNotification;
    @Column(name="is_sms")
    private Boolean isSMS;
    @Column(name="is_email")
    private Boolean isEmail;

    @Column(name="src_channel")
    private String srcChannel;

    @Column(name="created")
    private LocalDateTime created;

    @Column(name="updated")
    private LocalDateTime updated;

}

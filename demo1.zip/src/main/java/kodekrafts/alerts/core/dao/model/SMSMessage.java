package kodekrafts.alerts.core.dao.model;

import jakarta.persistence.*;

import java.time.LocalDateTime;
import java.util.StringJoiner;

@Entity(name = "email_message")
public class SMSMessage {
    @Id
    @Column(name="id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @Column(name="mobile_phone_number")
    private String mobilePhoneNumber;

    @Column(name="message")
    private String message;

    @Column(name="created")
    private LocalDateTime created;
    @Column(name="updated")
    private LocalDateTime updated;
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }
    public LocalDateTime getCreated() {
        return created;
    }
    public void setCreated(LocalDateTime created) {
        this.created = created;
    }
    public LocalDateTime getUpdated() {
        return updated;
    }

    public void setUpdated(LocalDateTime updated) {
        this.updated = updated;
    }

    public String getMobilePhoneNumber() {
        return mobilePhoneNumber;
    }

    public void setMobilePhoneNumber(String mobilePhoneNumber) {
        this.mobilePhoneNumber = mobilePhoneNumber;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", SMSMessage.class.getSimpleName() + "[", "]")
                .add("id=" + id)
                .add("mobilePhoneNumber='" + mobilePhoneNumber + "'")
                .add("message='" + message + "'")
                .add("created=" + created)
                .add("updated=" + updated)
                .toString();
    }
}

package kodekrafts.alerts.core.dao.model;

import jakarta.persistence.*;

import java.time.LocalDateTime;
import java.util.StringJoiner;

@Entity(name = "push_message")
public class PushMessage {
    @Id
    @Column(name="id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @Column(name="event_type")
    private String eventType;

    @Column(name="event_name")
    private String eventName;

    @Column(name="event_title")
    private String eventTitle;

    @Column(name="message")
    private String message;

    @Column(name="click_action")
    private String clickAction;
    @Column(name="created")
    private LocalDateTime created;
    @Column(name="updated")
    private LocalDateTime updated;
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getEventTitle() {
        return eventTitle;
    }

    public void setEventTitle(String eventTitle) {
        this.eventTitle = eventTitle;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getClickAction() {
        return clickAction;
    }

    public void setClickAction(String clickAction) {
        this.clickAction = clickAction;
    }

    public LocalDateTime getCreated() {
        return created;
    }

    public void setCreated(LocalDateTime created) {
        this.created = created;
    }

    public LocalDateTime getUpdated() {
        return updated;
    }

    public void setUpdated(LocalDateTime updated) {
        this.updated = updated;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", PushMessage.class.getSimpleName() + "[", "]")
                .add("id=" + id)
                .add("eventType='" + eventType + "'")
                .add("eventName='" + eventName + "'")
                .add("eventTitle='" + eventTitle + "'")
                .add("message='" + message + "'")
                .add("clickAction='" + clickAction + "'")
                .add("created=" + created)
                .add("updated=" + updated)
                .toString();
    }
}

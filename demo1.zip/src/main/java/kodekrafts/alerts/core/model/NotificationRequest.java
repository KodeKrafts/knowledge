package kodekrafts.alerts.core.model;

import java.util.List;
import java.util.StringJoiner;

public class NotificationRequest {
    private String correlationId;
    private String customerId;
    private String extendedMsg;
    private String language;
    private String customerEventName;
    private String fininstKey;
    private String applicationName;
    private String customerEventId;
    private String emailId;
    private List<Phone> phoneNumbers;
    private Boolean isPushNotification;
    private Boolean isSMS;
    private Boolean isEmail;
    private String srcChannel;

    public String getSrcChannel() {
        return srcChannel;
    }

    public void setSrcChannel(String srcChannel) {
        this.srcChannel = srcChannel;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getExtendedMsg() {
        return extendedMsg;
    }

    public void setExtendedMsg(String extendedMsg) {
        this.extendedMsg = extendedMsg;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getCustomerEventName() {
        return customerEventName;
    }

    public void setCustomerEventName(String customerEventName) {
        this.customerEventName = customerEventName;
    }

    public String getFininstKey() {
        return fininstKey;
    }

    public void setFininstKey(String fininstKey) {
        this.fininstKey = fininstKey;
    }

    public String getApplicationName() {
        return applicationName;
    }

    public void setApplicationName(String applicationName) {
        this.applicationName = applicationName;
    }

    public String getCustomerEventId() {
        return customerEventId;
    }

    public void setCustomerEventId(String customerEventId) {
        this.customerEventId = customerEventId;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public List<Phone> getPhoneNumbers() {
        return phoneNumbers;
    }

    public void setPhoneNumbers(List<Phone> phoneNumbers) {
        this.phoneNumbers = phoneNumbers;
    }

    public Boolean getPushNotification() {
        return isPushNotification;
    }

    public void setPushNotification(Boolean pushNotification) {
        isPushNotification = pushNotification;
    }

    public Boolean getSMS() {
        return isSMS;
    }

    public void setSMS(Boolean SMS) {
        isSMS = SMS;
    }

    public Boolean getEmail() {
        return isEmail;
    }

    public void setEmail(Boolean email) {
        isEmail = email;
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", NotificationRequest.class.getSimpleName() + "[", "]")
                .add("correlationId='" + correlationId + "'")
                .add("customerId='" + customerId + "'")
                .add("extendedMsg='" + extendedMsg + "'")
                .add("language='" + language + "'")
                .add("customerEventName='" + customerEventName + "'")
                .add("fininstKey='" + fininstKey + "'")
                .add("applicationName='" + applicationName + "'")
                .add("customerEventId='" + customerEventId + "'")
                .add("emailId='" + emailId + "'")
                .add("phoneNumbers=" + phoneNumbers)
                .add("isPushNotification=" + isPushNotification)
                .add("isSMS=" + isSMS)
                .add("isEmail=" + isEmail)
                .toString();
    }
}

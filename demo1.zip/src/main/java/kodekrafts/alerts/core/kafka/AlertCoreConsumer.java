package kodekrafts.alerts.core.kafka;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import kodekrafts.alerts.core.dao.NotificationRepository;
import kodekrafts.alerts.core.dao.model.Notification;
import kodekrafts.alerts.core.model.NotificationRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Component
public class AlertCoreConsumer {
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final static Logger logger = LoggerFactory.getLogger(AlertCoreConsumer.class);

    private final NotificationRepository notificationRepository;

    public AlertCoreConsumer(NotificationRepository notificationRepository){
        this.notificationRepository = notificationRepository;
    }
    @KafkaListener(id = "alerts-core-listener", topics = "alerts-core")
    public void listen(String in) {
        try {
            NotificationRequest request=  objectMapper.readValue(in, NotificationRequest.class);
            logger.info("Read message:{}", request);

            notificationRepository.save(getNotificationEntity(request));
        } catch (JsonProcessingException e) {
            logger.error("Error parsing message", e);
        }


    }

    private Notification getNotificationEntity(NotificationRequest request) {
        Notification result = new Notification();
        result.setCorrelationId(request.getCorrelationId());
        result.setCustomerId(request.getCustomerId());

        result.setApplicationName(request.getApplicationName());
        result.setExtendedMsg(request.getExtendedMsg());
        result.setLanguage(request.getLanguage());
        result.setCustomerEventName(request.getCustomerEventName());
        result.setFininstKey(request.getFininstKey());
        result.setCustomerEventId(request.getCustomerEventId());
        result.setEmailId(request.getEmailId());
        if(request.getPhoneNumbers() != null && !request.getPhoneNumbers().isEmpty()) {
            result.setPhoneNumber(request.getPhoneNumbers().get(0).getNumber());
            result.setPhoneType(request.getPhoneNumbers().get(0).getPhoneType());
        }
        result.setPushNotification(request.getPushNotification());
        result.setSMS(request.getSMS());
        result.setEmail(request.getEmail());
        result.setSrcChannel(request.getSrcChannel());
        result.setCreated(LocalDateTime.now());
        result.setUpdated(LocalDateTime.now());
        return result;
    }
}

package kodekrafts.alerts.rest.controllers;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import kodekrafts.alerts.rest.kafka.AlertCoreProducer;
import kodekrafts.alerts.rest.model.NotificationRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController()
@RequestMapping("/demo")
public class NotificationsController {
    private final static Logger logger = LoggerFactory.getLogger(NotificationsController.class);
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final AlertCoreProducer alertsProducer;

    public NotificationsController(AlertCoreProducer alertsProducer){
        this.alertsProducer = alertsProducer;
    }
    @PostMapping("/notifications")
    ResponseEntity<String> sendNotification(
            @RequestHeader("x-correlation-id") String xCorrelationId,
            @RequestBody NotificationRequest notificationRequest
    ) {
        logger.info("In sendNotification");
        notificationRequest.setCorrelationId(xCorrelationId);
        try {
            alertsProducer.send(objectMapper.writeValueAsString(notificationRequest));
        } catch (JsonProcessingException e) {
           return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
        return ResponseEntity.ok("Created");
    }
}

package kodekrafts.alerts.rest.model;

import java.util.List;

public class NotificationRequest {
    private String correlationId;
    private String customerId;
    private String extendedMsg;
    private String language;
    private String customerEventName;
    private String fininstKey;
    private String applicationName;
    private String customerEventId;
    private String emailId;
    private List<Phone> phoneNumbers;
    private Boolean isPushNotification;
    private Boolean isSMS;
    private Boolean isEmail;

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getExtendedMsg() {
        return extendedMsg;
    }

    public void setExtendedMsg(String extendedMsg) {
        this.extendedMsg = extendedMsg;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getCustomerEventName() {
        return customerEventName;
    }

    public void setCustomerEventName(String customerEventName) {
        this.customerEventName = customerEventName;
    }

    public String getFininstKey() {
        return fininstKey;
    }

    public void setFininstKey(String fininstKey) {
        this.fininstKey = fininstKey;
    }

    public String getApplicationName() {
        return applicationName;
    }

    public void setApplicationName(String applicationName) {
        this.applicationName = applicationName;
    }

    public String getCustomerEventId() {
        return customerEventId;
    }

    public void setCustomerEventId(String customerEventId) {
        this.customerEventId = customerEventId;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public List<Phone> getPhoneNumbers() {
        return phoneNumbers;
    }

    public void setPhoneNumbers(List<Phone> phoneNumbers) {
        this.phoneNumbers = phoneNumbers;
    }

    public Boolean getPushNotification() {
        return isPushNotification;
    }

    public void setPushNotification(Boolean pushNotification) {
        isPushNotification = pushNotification;
    }

    public Boolean getSMS() {
        return isSMS;
    }

    public void setSMS(Boolean SMS) {
        isSMS = SMS;
    }

    public Boolean getEmail() {
        return isEmail;
    }

    public void setEmail(Boolean email) {
        isEmail = email;
    }


    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    private String srcChannel;

    public String getSrcChannel() {
        return srcChannel;
    }

    public void setSrcChannel(String srcChannel) {
        this.srcChannel = srcChannel;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("NotificationRequest{");
        sb.append("customerId='").append(customerId).append('\'');
        sb.append(", extendedMsg='").append(extendedMsg).append('\'');
        sb.append(", language='").append(language).append('\'');
        sb.append(", customerEventName='").append(customerEventName).append('\'');
        sb.append(", fininstKey='").append(fininstKey).append('\'');
        sb.append(", applicationName='").append(applicationName).append('\'');
        sb.append(", customerEventId='").append(customerEventId).append('\'');
        sb.append(", emailId='").append(emailId).append('\'');
        sb.append(", phoneNumbers=").append(phoneNumbers);
        sb.append(", isPushNotification=").append(isPushNotification);
        sb.append(", isSMS=").append(isSMS);
        sb.append(", isEmail=").append(isEmail);
        sb.append('}');
        return sb.toString();
    }
}

package kodekrafts.alerts.rest.model;

public class NotificationResponse {
}

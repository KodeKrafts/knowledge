package kodekrafts.alerts.rest.kafka;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

@Component
public class AlertCoreProducer {
    @Autowired
    private KafkaTemplate<Object, Object> template;

    public void send(String message) {
        this.template.send("alerts-core", message);
    }
}

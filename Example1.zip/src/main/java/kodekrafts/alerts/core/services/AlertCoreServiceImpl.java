package kodekrafts.alerts.core.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import kodekrafts.alerts.core.dao.AlertLogRepository;
import kodekrafts.alerts.core.dao.AlertMessageRepository;
import kodekrafts.alerts.core.dao.model.*;
import kodekrafts.alerts.core.rest.model.NotificationRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
@Component
public class AlertCoreServiceImpl implements AlertCoreService{
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final static Logger logger = LoggerFactory.getLogger(AlertCoreServiceImpl.class);
    private final AlertLogRepository alertLogRepository;
    private final AlertMessageRepository alertMessageRepository;
    public AlertCoreServiceImpl(AlertLogRepository alertLogRepository, AlertMessageRepository alertMessageRepository){
        this.alertLogRepository = alertLogRepository;
        this.alertMessageRepository = alertMessageRepository;
    }
    @Override
    public void processAlertMessage(String in) {
        try {
            NotificationRequest request = objectMapper.readValue(in, NotificationRequest.class);
            logger.info("Read message:{}", request);
            AlertLog alertLog = alertLogRepository.findByCorrelationId(request.getCorrelationId());
            if (alertLog == null) {
                alertLogRepository.save(getAlertLogEntity(request, in, false));
                alertMessageRepository.save(getAlertMessageEntiry(request));
            } else {
                alertLogRepository.save(getAlertLogEntity(request, in, true));
            }
        }catch (JsonProcessingException e){
            throw new RuntimeException(e);
        }
    }

    private AlertMessage getAlertMessageEntiry(NotificationRequest request) {
        AlertMessage result = new AlertMessage();
        result.setCorrelationId(request.getCorrelationId());
        result.setCustomerId(request.getCustomerId());
        result.setBankNumber(request.getBankNumber());
        result.setSourceChannel(request.getSourceChannel());
        result.setNotificationType(request.getNotificationType());
        result.setCreated(LocalDateTime.now());
        result.setUpdated(LocalDateTime.now());
        if(request.getPush()!= null){
            result.setPush(getPushEntity(request.getPush()));
        }
        if(request.getEmail() != null){
            result.setEmail(getEmailEntity(request.getEmail()));
        }
        if(request.getSms() != null){
            result.setSms(getSMSEntity(request.getSms()));
        }
        return result;
    }

    private SMSMessage getSMSEntity(kodekrafts.alerts.core.rest.model.SMSMessage sms) {
        SMSMessage result = new SMSMessage();
        result.setMessage(sms.getMessage());
        result.setMobilePhoneNumber(sms.getMobilePhoneNumber());
        result.setStatus("N");
        result.setCreated(LocalDateTime.now());
        result.setUpdated(LocalDateTime.now());
        return result;
    }

    private EmailMessage getEmailEntity(kodekrafts.alerts.core.rest.model.EmailMessage email) {
        EmailMessage result = new EmailMessage();
        result.setSubject(email.getSubject());
        result.setMessage(email.getMessage());
        result.setAddress(email.getAddress());
        result.setStatus("N");
        result.setCreated(LocalDateTime.now());
        result.setUpdated(LocalDateTime.now());
        return result;
    }


    private PushMessage getPushEntity(kodekrafts.alerts.core.rest.model.PushMessage push) {
        PushMessage result = new PushMessage();
        result.setEventType(push.getEventType());
        result.setEventName(push.getEventName());
        result.setEventTitle(push.getEventTitle());
        result.setMessage(push.getExtendedMsg());
        result.setClickAction(push.getClickAction());
        result.setStatus("N");
        result.setCreated(LocalDateTime.now());
        result.setUpdated(LocalDateTime.now());
        return result;
    }

    private AlertLog getAlertLogEntity(NotificationRequest request, String requestString, boolean duplicate) {
        AlertLog result = new AlertLog();
        result.setCorrelationId(request.getCorrelationId());
        result.setCustomerId(request.getCustomerId());
        result.setNotificationType(request.getNotificationType());
        result.setPayload(requestString);
        result.setCreated(LocalDateTime.now());
        result.setUpdated(LocalDateTime.now());
        result.setDuplicate(duplicate);
        return result;
    }
}

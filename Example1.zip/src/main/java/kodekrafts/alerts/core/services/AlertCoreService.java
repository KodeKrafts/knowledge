package kodekrafts.alerts.core.services;

public interface AlertCoreService {

    void processAlertMessage(String requestStr);

}

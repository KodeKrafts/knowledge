package kodekrafts.alerts.core.kafka;

//import com.fasterxml.jackson.core.JsonProcessingException;
//import com.fasterxml.jackson.databind.ObjectMapper;
//
//import kodekrafts.alerts.core.dao.AlertLogRepository;
//import kodekrafts.alerts.core.dao.NotificationRepository;
//import kodekrafts.alerts.core.dao.model.AlertLog;
//import kodekrafts.alerts.core.rest.model.NotificationRequest;

import kodekrafts.alerts.core.services.AlertCoreService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class AlertCoreConsumer {
    private final static Logger logger = LoggerFactory.getLogger(AlertCoreConsumer.class);

    private final AlertCoreService alertCoreService;

    public AlertCoreConsumer(AlertCoreService alertCoreService) {
        this.alertCoreService = alertCoreService;
    }

    @KafkaListener(id = "alerts-core-listener", topics = "alerts-core")
    public void listen(String in) {
        try {
            alertCoreService.processAlertMessage(in);
        } catch (Exception e) {
            logger.error("Error processing message", e);
        }
    }


}

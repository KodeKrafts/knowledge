package kodekrafts.alerts.core.rest.model;

import java.util.List;
import java.util.StringJoiner;

public class NotificationRequest {
    private String correlationId;
    private String customerId;
    private String bankNumber;
    private String sourceChannel;
    private String notificationType;
    private PushMessage push;
    private EmailMessage email;
    private SMSMessage sms;

    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getBankNumber() {
        return bankNumber;
    }

    public void setBankNumber(String bankNumber) {
        this.bankNumber = bankNumber;
    }

    public String getSourceChannel() {
        return sourceChannel;
    }

    public void setSourceChannel(String sourceChannel) {
        this.sourceChannel = sourceChannel;
    }

    public String getNotificationType() {
        return notificationType;
    }

    public void setNotificationType(String notificationType) {
        this.notificationType = notificationType;
    }

    public PushMessage getPush() {
        return push;
    }

    public void setPush(PushMessage push) {
        this.push = push;
    }

    public EmailMessage getEmail() {
        return email;
    }

    public void setEmail(EmailMessage email) {
        this.email = email;
    }

    public SMSMessage getSms() {
        return sms;
    }

    public void setSms(SMSMessage sms) {
        this.sms = sms;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", NotificationRequest.class.getSimpleName() + "[", "]")
                .add("correlationId='" + correlationId + "'")
                .add("customerId='" + customerId + "'")
                .add("bankNumber='" + bankNumber + "'")
                .add("sourceChannel='" + sourceChannel + "'")
                .add("notificationType='" + notificationType + "'")
                .add("push=" + push)
                .add("email=" + email)
                .add("sms=" + sms)
                .toString();
    }
}

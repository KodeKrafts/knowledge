package kodekrafts.alerts.core.rest.model;

import java.time.LocalDateTime;

public class EmailMessage {
    private String subject;
    private String message;
    private String address;

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}

package kodekrafts.alerts.core.rest.model;

import java.util.StringJoiner;

public class PushMessage {
    private String eventType;
    private String eventName;
    private String eventTitle;
    private String extendedMsg;
    private String clickAction;

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getEventTitle() {
        return eventTitle;
    }

    public void setEventTitle(String eventTitle) {
        this.eventTitle = eventTitle;
    }

    public String getExtendedMsg() {
        return extendedMsg;
    }

    public void setExtendedMsg(String extendedMsg) {
        this.extendedMsg = extendedMsg;
    }

    public String getClickAction() {
        return clickAction;
    }

    public void setClickAction(String clickAction) {
        this.clickAction = clickAction;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", PushMessage.class.getSimpleName() + "[", "]")
                .add("eventType='" + eventType + "'")
                .add("eventName='" + eventName + "'")
                .add("eventTitle='" + eventTitle + "'")
                .add("extendedMsg='" + extendedMsg + "'")
                .add("clickAction='" + clickAction + "'")
                .toString();
    }
}

package kodekrafts.alerts.core.dao;

import kodekrafts.alerts.core.dao.model.AlertMessage;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AlertMessageRepository extends JpaRepository<AlertMessage, Long> {
}

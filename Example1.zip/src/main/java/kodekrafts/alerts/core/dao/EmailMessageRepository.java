package kodekrafts.alerts.core.dao;

import kodekrafts.alerts.core.dao.model.EmailMessage;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmailMessageRepository extends JpaRepository<EmailMessage, Long> {
}

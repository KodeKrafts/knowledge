package kodekrafts.alerts.core.dao;

import kodekrafts.alerts.core.dao.model.SMSMessage;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SMSMessageRepository extends JpaRepository<SMSMessage, Long> {
}

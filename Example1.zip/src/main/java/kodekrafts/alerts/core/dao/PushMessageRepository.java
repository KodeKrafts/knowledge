package kodekrafts.alerts.core.dao;

import kodekrafts.alerts.core.dao.model.PushMessage;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PushMessageRepository extends JpaRepository<PushMessage, Long> {
}

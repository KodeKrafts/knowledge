package kodekrafts.alerts.core.dao.model;

import jakarta.persistence.*;

import java.time.LocalDateTime;
import java.util.StringJoiner;

@Entity(name = "alert_log")
public class AlertLog {

    @Id
    @Column(name="id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @Column(name="correlation_id")
    private String correlationId;
    @Column(name="customer_id")
    private String customerId;

    @Column(name="notification_type")
    private String notificationType;

    @Column(name="payload")
    private String payload;

    @Column(name="duplicate")
    private boolean duplicate;

    @Column(name="created")
    private LocalDateTime created;

    @Column(name="updated")
    private LocalDateTime updated;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getPayload() {
        return payload;
    }

    public void setPayload(String payload) {
        this.payload = payload;
    }

    public boolean isDuplicate() {
        return duplicate;
    }

    public void setDuplicate(boolean duplicate) {
        this.duplicate = duplicate;
    }

    public LocalDateTime getCreated() {
        return created;
    }

    public void setCreated(LocalDateTime created) {
        this.created = created;
    }

    public LocalDateTime getUpdated() {
        return updated;
    }

    public void setUpdated(LocalDateTime updated) {
        this.updated = updated;
    }

    public String getNotificationType() {
        return notificationType;
    }

    public void setNotificationType(String notificationType) {
        this.notificationType = notificationType;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", AlertLog.class.getSimpleName() + "[", "]")
                .add("id=" + id)
                .add("correlationId='" + correlationId + "'")
                .add("customerId='" + customerId + "'")
                .add("notificationType='" + notificationType + "'")
                .add("payload='" + payload + "'")
                .add("duplicate=" + duplicate)
                .add("created=" + created)
                .add("updated=" + updated)
                .toString();
    }
}

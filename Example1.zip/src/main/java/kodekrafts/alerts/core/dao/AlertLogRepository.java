package kodekrafts.alerts.core.dao;

import kodekrafts.alerts.core.dao.model.AlertLog;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AlertLogRepository extends JpaRepository<AlertLog, Long> {

    AlertLog findByCorrelationId(String correlationId);
}

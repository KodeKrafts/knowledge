package kodekrafts.alerts.core.dao.model;

import jakarta.persistence.*;

import java.time.LocalDateTime;
import java.util.StringJoiner;

@Entity(name = "alert_message")

public class AlertMessage {
    @Id
    @Column(name="id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name="correlation_id")
    private String correlationId;
    @Column(name="customer_id")
    private String customerId;

    @Column(name="bank_number")
    private String bankNumber;
    @Column(name="source_channel")
    private String sourceChannel;

    @Column(name="notification_type")
    private String notificationType;
    @Column(name="created")
    private LocalDateTime created;
    @Column(name="updated")
    private LocalDateTime updated;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "push_id", referencedColumnName = "id")
    private PushMessage push;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "sms_id", referencedColumnName = "id")
    private SMSMessage sms;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "email_id", referencedColumnName = "id")
    private EmailMessage email;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getBankNumber() {
        return bankNumber;
    }

    public void setBankNumber(String bankNumber) {
        this.bankNumber = bankNumber;
    }

    public String getSourceChannel() {
        return sourceChannel;
    }

    public void setSourceChannel(String sourceChannel) {
        this.sourceChannel = sourceChannel;
    }

    public String getNotificationType() {
        return notificationType;
    }

    public void setNotificationType(String notificationType) {
        this.notificationType = notificationType;
    }

    public LocalDateTime getCreated() {
        return created;
    }

    public void setCreated(LocalDateTime created) {
        this.created = created;
    }

    public LocalDateTime getUpdated() {
        return updated;
    }

    public void setUpdated(LocalDateTime updated) {
        this.updated = updated;
    }

    public PushMessage getPush() {
        return push;
    }

    public void setPush(PushMessage push) {
        this.push = push;
    }

    public SMSMessage getSms() {
        return sms;
    }

    public void setSms(SMSMessage sms) {
        this.sms = sms;
    }

    public EmailMessage getEmail() {
        return email;
    }

    public void setEmail(EmailMessage email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", AlertMessage.class.getSimpleName() + "[", "]")
                .add("id=" + id)
                .add("correlationId='" + correlationId + "'")
                .add("customerId='" + customerId + "'")
                .add("bankNumber='" + bankNumber + "'")
                .add("sourceChannel='" + sourceChannel + "'")
                .add("notificationType='" + notificationType + "'")
                .add("created=" + created)
                .add("updated=" + updated)
                .add("push=" + push)
                .add("sms=" + sms)
                .add("email=" + email)
                .toString();
    }
}

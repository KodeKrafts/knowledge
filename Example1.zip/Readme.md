# Getting Started

### Reference Documentation
For further reference, please consider the following sections:

* [Official Apache Maven documentation](https://maven.apache.org/guides/index.html)
* [Spring Boot Maven Plugin Reference Guide](https://docs.spring.io/spring-boot/docs/3.3.0/maven-plugin/reference/html/)
* [Create an OCI image](https://docs.spring.io/spring-boot/docs/3.3.0/maven-plugin/reference/html/#build-image)
* [Spring Data JPA](https://docs.spring.io/spring-boot/docs/3.3.0/reference/htmlsingle/index.html#data.sql.jpa-and-spring-data)
* [Spring for Apache Kafka](https://docs.spring.io/spring-boot/docs/3.3.0/reference/htmlsingle/index.html#messaging.kafka)

### Guides
The following guides illustrate how to use some features concretely:

* [Accessing Data with JPA](https://spring.io/guides/gs/accessing-data-jpa/)


```


IF OBJECT_ID(N'dbo.alert_log', N'U') IS NOT NULL  
   DROP TABLE [dbo].[alert_log];  
GO


CREATE TABLE [dbo].[alert_log](
[id]	INT IDENTITY NOT NULL,
[correlation_id]	NVARCHAR(36) 	NOT NULL, 
[customer_id]	NVARCHAR(36) NOT NULL,
[notification_type]	NVARCHAR(36) NOT NULL,
[payload] NVARCHAR(MAX) NULL,
[duplicate]	BIT NULL,
[created]	DATETIME 	NOT NULL,
[updated]	DATETIME 	NOT NULL
)
GO

IF OBJECT_ID(N'dbo.push_message', N'U') IS NOT NULL  
   DROP TABLE [dbo].[push_message];  
GO

CREATE TABLE [dbo].[push_message](
[id]	INT IDENTITY NOT NULL,
[event_type]	NVARCHAR(36) NOT NULL,
[event_name]	NVARCHAR(255) NULL,
[event_title]	NVARCHAR(255) NULL,
[message]	NVARCHAR(255) NULL,
[click_action] NVARCHAR(36) NULL,
[status] NVARCHAR(1) NULL,
[created]	DATETIME 	NOT NULL,
[updated]	DATETIME 	NOT NULL,
CONSTRAINT PK_PUSH_MESSAGE PRIMARY KEY (id)

)
GO

CREATE INDEX ALERT_LOG_CORRELATION_IDX on [dbo].[alert_log] (correlation_id);

IF OBJECT_ID(N'dbo.email_message', N'U') IS NOT NULL  
   DROP TABLE [dbo].[email_message];  
GO


CREATE TABLE [dbo].[email_message](
[id]	INT IDENTITY NOT NULL,
[subject]	NVARCHAR(36) NOT NULL,
[message]	NVARCHAR(255) NULL,
[address]	NVARCHAR(255) NULL,
[status] NVARCHAR(1) NULL,
[created]	DATETIME 	NOT NULL,
[updated]	DATETIME 	NOT NULL,
CONSTRAINT PK_EMAIL_MESSAGE PRIMARY KEY (id)
)
GO

IF OBJECT_ID(N'dbo.sms_message', N'U') IS NOT NULL  
   DROP TABLE [dbo].[sms_message];  
GO


CREATE TABLE [dbo].[sms_message](
[id]	INT IDENTITY NOT NULL,
[mobile_phone_number]	NVARCHAR(14) NOT NULL,
[message]	NVARCHAR(255) NULL,
[status] NVARCHAR(1) NULL,
[created]	DATETIME 	NOT NULL,
[updated]	DATETIME 	NOT NULL,
CONSTRAINT PK_SMS_MESSAGE PRIMARY KEY (id)

)
GO

IF OBJECT_ID(N'dbo.alert_message', N'U') IS NOT NULL  
   DROP TABLE [dbo].[alert_message];  
GO


CREATE TABLE [dbo].[alert_message](
[id]	INT IDENTITY NOT NULL,
[correlation_id]	NVARCHAR(36) 	NOT NULL, 
[customer_id]	NVARCHAR(36) NOT NULL,
[bank_number]	NVARCHAR(255) NULL,
[source_channel]	NVARCHAR(36) NULL,
[notification_type]	NVARCHAR(36) NULL,
[push_id] INT NULL,
[sms_id] INT NULL,
[email_id] INT NULL,
[created]	DATETIME 	NOT NULL,
[updated]	DATETIME 	NOT NULL,
CONSTRAINT PK_ALERT_MESSAGE PRIMARY KEY (id),
CONSTRAINT FK_PUSH_MESSAGE FOREIGN KEY (push_id) REFERENCES dbo.push_message (id),
CONSTRAINT FK_SMS_MESSAGE FOREIGN KEY (sms_id) REFERENCES dbo.sms_message (id),
CONSTRAINT FK_EMAIL_MESSAGE FOREIGN KEY (email_id) REFERENCES dbo.email_message (id),
)
GO

```
